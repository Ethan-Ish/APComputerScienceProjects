import java.awt.*;
import java.util.*;
import java.util.List;

public class Caesar implements EncryptAlgo
{
    
    String[] remixedAlphabet = new String[26];
    
    private int offset = 0;
    
    public String encrypt(String input){
        int random = (int) Math.floor(Math.random() * Alphabet.alphabet.length);
        offset = random;
        remixedAlphabet = remixAlphabet(offset);
        String returnString = apply(input, remixedAlphabet);        
        return returnString;
    }
    
    public int getOffset(){
        return offset;
    }
    
    public String decrypt(int test, String input){
        String returnString = apply(input, remixAlphabet(test * -1));
        return returnString;
    }
    
    public String apply(String input, String[] newAlph){
        String returnString = new String(input);
        String[] sent = input.substring(0).split("");
        for(int i = 0; i < sent.length; i++)
        {
            if(Character.isLetter(sent[i].charAt(0)))
            {
                int index = getIndex(sent[i]);
                sent[i] = newAlph[index];
            }
        }
        returnString = "";
        for(int i = 0; i < sent.length; i++)
        {
            returnString = returnString + sent[i];
        }
        return returnString;
    }
    
    private int getIndex(String input){
        int returnInt = -1;
        if(Character.isLetter(input.charAt(0)))
        {
            for(int i = 0; i < Alphabet.alphabet.length; i++){
                if(input.equals(Alphabet.alphabet[i]))
                {
                    returnInt = i;
                }
            }
        }
        return returnInt;
    }
    
    private String[] remixAlphabet(int offset){
        List<String> returnString = new ArrayList<String>();
        List<String> alphabetList = new ArrayList<String>();
        String[] newAlph = new String[26];
        for(int i = 0; i < Alphabet.alphabet.length; i++)
        {
            alphabetList.add(Alphabet.alphabet[i]);
        }
        for(int j = 0; j < Alphabet.alphabet.length; j++)
        {
            int i = j + offset;
            while(i >= alphabetList.size())
            {
                i -= alphabetList.size();
            }
            while(i < 0)
            {
                i += alphabetList.size();
            }
            returnString.add(alphabetList.get(i));
        }
        for(int i = 0; i < newAlph.length; i++)
        {
            newAlph[i] = returnString.get(i);
        }
        return newAlph;
    }
    
}
