import java.util.HashMap;
public class LetterFreq
{
    
    public static int[] letterFreq(String input)
    {
        String[] sent = input.substring(0).split("");
        HashMap<String, Integer> freqs = new HashMap<String, Integer>();
        freqs.clear();
        for(int i = 0; i < sent.length; i++)
        {
            if(Character.isLetter(sent[i].charAt(0)))
            {
                int occurence = 0;
                if(!freqs.containsKey(sent[i]))
                {
                    occurence = 1;
                }
                else
                {
                    occurence = freqs.get(sent[i]) + 1;
                }
                freqs.put(sent[i], occurence);
            }
        }
        int[] alphabetFreqs = new int[26];
        for(int i = 0; i < alphabetFreqs.length; i++)
        {
            String key = Alphabet.alphabet[i];
            if(!freqs.containsKey(key))
            {
                freqs.put(key, 0);
            }
            alphabetFreqs[i] = freqs.get(key);
        }
        return alphabetFreqs;
    }
    
}
