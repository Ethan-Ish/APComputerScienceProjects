
/**
 * Write a description of interface EncryptAlgo here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public interface EncryptAlgo
{
    
    String encrypt(String input);
    
}
