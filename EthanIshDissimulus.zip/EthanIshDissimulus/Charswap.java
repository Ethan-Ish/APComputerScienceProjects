import java.awt.*;
import java.util.*;
import java.util.List;

public class Charswap implements EncryptAlgo
{
    
    private int seed;
    
    private int[] currArr;
    
    public void setSeed(int newSeed){
        seed = newSeed;
    }
    
    public int getSeed(){
        return seed;
    }
    
    public String decrypt(String input, int test)
    {
        System.out.flush();
        String returnString = new String(input);
        int[] intArray = new int[input.length()];
        for(int i = 0; i < input.length(); i++)
        {
            intArray[i] = currArr[i];
        }
        for(int i = 0; i < intArray.length; i++)
        {
            if(intArray[i] != 32)
            {
                intArray[i] = (int)Math.round((double)intArray[i] / (double)test);
            }
        }
        returnString = "";
        for(int i = 0; i < intArray.length; i++)
        {
            returnString = returnString + (char)intArray[i];
        }
        return returnString;
    }
    
    public String encrypt(String input){
        String returnString = new String(input);
        int[] intArray = new int[input.length()];
        currArr = new int[input.length()];
        for(int i = 0; i < input.length(); i++)
        {
            intArray[i] = (int)input.charAt(i);
            currArr[i] = intArray[i];
        }
        for(int i = 0; i < intArray.length; i++)
        {
            if(intArray[i] != 32)
            {
                intArray[i] = intArray[i] * seed;
                currArr[i] = intArray[i];
            }
        }
        returnString = "";
        for(int i = 0; i < intArray.length; i++)
        {
            returnString = returnString + (char)intArray[i];
        }
        return returnString;
    }
    
}
