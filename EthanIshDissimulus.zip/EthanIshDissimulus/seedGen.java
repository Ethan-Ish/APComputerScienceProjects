import java.time.*;
import java.io.*;
import java.awt.*;
import java.util.*;
import java.util.List;
/**
 * Write a description of class seedGen here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class seedGen
{
    
    public static final int seedCount = 7;
    
    public static int getSeed(int seedSelect)
    {
        int returnSeed = 0;
        if(seedSelect == 0) // Today's date
        {
            returnSeed = dateToNumber(LocalDate.now());
        }
        else if(seedSelect == 1) // Current time
        {
            returnSeed = timeToNumber(LocalTime.now());
        }
        else if(seedSelect == 2) // Meaning of the universe
        {
            returnSeed = 42;
        }
        else if(seedSelect == 3) // Birthdate of Alan Turing
        {
            returnSeed = dateToNumber(LocalDate.of(1912, Month.JUNE, 23));
        }
        else if(seedSelect == 4) // Pi
        {
            returnSeed = 314159;
        }
        else if(seedSelect == 5) // e
        {
            returnSeed = 271828;
        }
        else if(seedSelect == 6) // Release date of Pong
        {
            returnSeed = dateToNumber(LocalDate.of(1972, Month.NOVEMBER, 29));
        }
        else if(seedSelect == 7) // Rick Roll
        {
            returnSeed = dateToNumber(LocalDate.of(1987, Month.JULY, 27));
        }
        return returnSeed;
    }
    
    public static final String[] hints = {"They often use the current date for their keys.", 
    "They often use the current time for their keys.", 
    "They're a big fan of 'Hitchhiker's Guide to the Galaxy,' and often refernece their favorite quote from it.", 
    "They idolize Alan Turing, and often use references to him in their encryption.",
    "They're fascinated with the occurence of the first 5 digits of pi.",
    "They're fascinated with the occurence of the first 5 digits of Euler's number.",
    "They're a big fan of retro games, and often reference Pong in their encryption.",
    "They're never going to give you up or let you down, nor run around and dessert you."};
    
    private static int dateToNumber(LocalDate date)
    {
        String dateNumber = "";
        if(date.getMonthValue() < 10) // add month
        {
            dateNumber = dateNumber + "0";
        }
        dateNumber = dateNumber + Integer.toString(date.getMonthValue());
        if(date.getDayOfMonth() < 10) // add day
        {
            dateNumber = dateNumber + "0";
        }
        dateNumber = dateNumber + Integer.toString(date.getDayOfMonth());
        dateNumber = dateNumber + Integer.toString(date.getYear()).substring(2); // add last 2 digits of year
        return Integer.parseInt(dateNumber);
    }
    
    private static int timeToNumber(LocalTime time)
    {
        String timeNumber = "";
        if(time.getHour() < 10) // add hour
        {
            timeNumber = timeNumber + "0";
        }
        timeNumber = timeNumber + Integer.toString(time.getHour());
        if(time.getMinute() < 10) // add minute
        {
            timeNumber = timeNumber + "0";
        }
        timeNumber = timeNumber + Integer.toString(time.getMinute());
        return Integer.parseInt(timeNumber);
    }
    
    public static int[] getRandSeed()
    {
        int[] returnArr = new int[2];
        int seedSelect = (int)(Math.floor(Math.random() * (seedCount+1)));
        int firstTwo = (int)(Math.floor(Math.random() * 5));
        if(firstTwo < 1)
        {
            seedSelect = (int)(Math.floor(Math.random() * 2));
        }
        int seed = getSeed(seedSelect);
        returnArr[0] = seed;
        returnArr[1] = seedSelect;
        return returnArr;
    }
    
}
