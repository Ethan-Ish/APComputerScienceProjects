import java.awt.*;
import java.util.*;
import java.io.*;
import java.util.List;
/**
 * Write a description of class Encrypter here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Encrypter
{
    
    public static String getSentence()
    {
        String returnString = "Something went wrong, this isnt from the file";
        List<String> wordList = new ArrayList<String>();
        try{
            Scanner scanner = new Scanner(new File("sentences.txt"));
            
            while (scanner.hasNextLine()) {
                wordList.add(scanner.nextLine());
            }
            
            int random = (int) Math.floor(Math.random() * wordList.size());
            
            returnString = wordList.get(random);
        }
        catch(FileNotFoundException ex) {
            ex.printStackTrace();
        }
        return returnString;
    }
    
    public static String encrypt(String input, EncryptAlgo[] algos){
        String output = new String(input);
        for(int i = 0; i < algos.length; i++)
        {
            EncryptAlgo algo = algos[i];
            output = algo.encrypt(output);
        }
        return output;
    }
    
}
