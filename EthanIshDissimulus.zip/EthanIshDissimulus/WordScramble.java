import java.awt.*;
import java.util.*;
import java.util.List;
public class WordScramble implements EncryptAlgo
{
    
    public String encrypt(String input)
    {
        String returnString = new String(input);
        String[] words = returnString.split(" ");
        List<String> wordList = new ArrayList<String>();
        List<String> remixedWords = new ArrayList<String>();
        for(int i = 0; i < words.length; i++)
        {
            wordList.add(words[i]);
        }
        for(int i = 0; i < words.length; i++)
        {
            int random = (int)(Math.floor(Math.random() * wordList.size()));
            remixedWords.add(wordList.get(random));
            wordList.remove(random);
        }
        for(int i = 0; i < words.length; i++)
        {
            words[i] = remixedWords.get(i);
        }
        returnString = "";
        for(int i = 0; i < words.length; i++)
        {
            returnString = returnString + words[i];
            if(!(i == words.length - 1))
            {
                returnString = returnString + " ";
            }
        }
        return returnString;
    }
    
}
