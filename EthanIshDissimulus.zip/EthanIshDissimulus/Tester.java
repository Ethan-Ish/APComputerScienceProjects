import java.time.*;
import java.io.*;
import java.awt.*;
import java.util.*;
import java.util.List;
public class Tester
{
    
    public static void main(String[] args)
    {
        Charswap algo2 = new Charswap();
        int[] seedData = seedGen.getRandSeed();
        algo2.setSeed(seedData[0]);
        Caesar algo = new Caesar();
        LetterRandom scramble1 = new LetterRandom();
        scramble1.setChance(10);
        WordScramble scramble2 = new WordScramble();
        
        String original = Encrypter.getSentence();
        String scrambled1 = scramble1.encrypt(original);
        String scrambled2 = scramble2.encrypt(scrambled1);
        
        
        String sentence = algo.encrypt(scrambled2);
        String sentence2 = algo2.encrypt(sentence);
        System.out.println(sentence2);
        
        Scanner myObj = new Scanner(System.in);
        
        String decrypt = "";
        
        System.out.println(seedGen.hints[seedData[1]]);
        
        while(!(decrypt.equals(sentence)))
        {
            int seed = Integer.parseInt(myObj.nextLine());
            decrypt = algo2.decrypt(sentence2, seed);
            System.out.println(decrypt);
        }
        System.out.println("Key decrypted! Now the next one.");
        while(!(decrypt.equals(scrambled2)))
        {
            int offset = Integer.parseInt(myObj.nextLine());
            decrypt = algo.decrypt(offset, sentence);
            System.out.println(decrypt);
        }
        System.out.println("Key decrypted! Now the next one.");
        while(!(decrypt.equals(original)))
        {
            decrypt = myObj.nextLine();
            System.out.println(decrypt);
        }
        System.out.println("Awesome job!");
    }
    
}
