import java.awt.*;
import java.util.*;
import java.util.List;
public class Substitution implements EncryptAlgo
{
        
    String[] remixedAlphabet = new String[26];
    
    public String encrypt(String input){
        remixAlphabet();
        String returnString = apply(remixedAlphabet, input);
        return returnString;
    }
    
    public String decrypt(String[] test, String input)
    {
        String returnString = new String(input);
        String[] sent = input.substring(0).split("");
        for(int i = 0; i < sent.length; i++)
        {
            if(Character.isLetter(sent[i].charAt(0)))
            {
                int index = getIndex(sent[i], test);
                sent[i] = Alphabet.alphabet[index];
            }
        }
        returnString = "";
        for(int i = 0; i < sent.length; i++)
        {
            returnString = returnString + sent[i];
        }
        return returnString;
    }
    
    public String[] getAlphabet(){
        String[] remixedAlph = new String[26];
        for(int i = 0;  i < remixedAlphabet.length; i++)
        {
            remixedAlph[i] = remixedAlphabet[i];
        }
        return remixedAlph;
    }
    
    public String apply(String[] newAlph, String input)
    {
        String returnString = new String(input);
        String[] sent = input.substring(0).split("");
        for(int i = 0; i < sent.length; i++)
        {
            if(Character.isLetter(sent[i].charAt(0)))
            {
                int index = getIndex(sent[i], Alphabet.alphabet);
                sent[i] = remixedAlphabet[index];
            }
        }
        returnString = "";
        for(int i = 0; i < sent.length; i++)
        {
            returnString = returnString + sent[i];
        }
        return returnString;
    }
    
    private int getIndex(String input, String[] array){
        int returnInt = -1;
        if(Character.isLetter(input.charAt(0)))
        {
            for(int i = 0; i < array.length; i++){
                if(input.equals(array[i]))
                {
                    returnInt = i;
                }
            }
        }
        return returnInt;
    }
    
    public void remixAlphabet(){
        List<String> returnString = new ArrayList<String>();
        List<String> alphabetList = new ArrayList<String>();
        for(int i = 0; i < Alphabet.alphabet.length; i++)
        {
            alphabetList.add(Alphabet.alphabet[i]);
        }
        for(int i = 0; i < Alphabet.alphabet.length; i++)
        {
            int random = (int) Math.floor(Math.random() * alphabetList.size());
            returnString.add(alphabetList.get(random));
            alphabetList.remove(random);
        }
        for(int i = 0; i < remixedAlphabet.length; i++)
        {
            remixedAlphabet[i] = returnString.get(i);
        }
    }
    
}
