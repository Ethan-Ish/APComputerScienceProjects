
/**
 * Write a description of class LetterRandom here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class LetterRandom implements EncryptAlgo
{
    
    private int chance = 15;
    
    public void setChance(int chanceInp)
    {
        this.chance = chanceInp;
    }
    
    public String encrypt(String input){
        String returnString = new String(input);
        String[] sent = input.substring(0).split("");
        for(int i = 0; i < sent.length; i++)
        {
            if(Character.isLetter(sent[i].charAt(0)))
            {
                int random = (int)(Math.floor(Math.random() * chance));
                if(random < 1)
                {
                    int newLetter = (int)(Math.floor(Math.random() * Alphabet.alphabet.length));
                    sent[i] = Alphabet.alphabet[newLetter];
                }
            }
        }
        returnString = "";
        for(int i = 0; i < sent.length; i++)
        {
            returnString = returnString + sent[i];
        }
        return returnString;
    }
    
}
